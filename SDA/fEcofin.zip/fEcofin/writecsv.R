library(fEcofin)
xx = as.matrix(msft.dat)
write.csv(xx,"msft.csv",row.names=F)